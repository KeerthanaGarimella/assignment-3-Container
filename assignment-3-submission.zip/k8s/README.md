# ansible-k8s
k3d or k3s with up.yml and down.yml
